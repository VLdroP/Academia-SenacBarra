
export interface Cliente{

    id: string
    nome: string
    cpf: string
    email: string
    telefone: string
    endereco: string
    
}
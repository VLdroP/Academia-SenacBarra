import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-content',
  templateUrl: './content.component.html',
  styleUrls: ['./content.component.css']
})
export class ContentComponent implements OnInit {

  ngOnInit(): void {
    }

    constructor(private router: Router){ }

    gotoCadastroClientes(){

      this.router.navigate(['cadastro-clientes'])
    }

    gotoPlanos(){
      this.router.navigate(['planos'])
      
    }
  



}
